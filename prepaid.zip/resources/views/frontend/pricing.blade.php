@extends('layouts.app')

@section('content')
<section id="pricing" class="py-5">
    <div class="container">
        <div class="row">
            <div class="col-12"></div>
        </div>
        <h3 class="text-capitalize color-primary mb-5 wow fadeIn animated up">1</h1>
    </div>
</section>
@endsection
